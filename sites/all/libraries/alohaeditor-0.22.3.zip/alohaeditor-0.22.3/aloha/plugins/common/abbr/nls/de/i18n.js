define({
	"floatingmenu.tab.abbr": "Abkürzung",
	"button.addabbr.tooltip": "Abkürzung einfügen",
	"button.abbr.tooltip": "Als Abkürzung formatieren",
	"newabbr.defaulttext": "Abb"
});
