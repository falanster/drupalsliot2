define({
	"button.createulist.tooltip": "插入无序列表",
	"button.createolist.tooltip": "插入有序列表",
	"button.indentlist.tooltip": "缩进列表",
	"button.outdentlist.tooltip": "凸出列表",
	"floatingmenu.tab.list": "列表"
});
