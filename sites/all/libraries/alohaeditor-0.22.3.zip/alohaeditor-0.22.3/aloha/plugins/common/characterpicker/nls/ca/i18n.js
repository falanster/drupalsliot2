define({
	"button.addcharacter.tooltip": "Trieu els caràcters especials"
});
