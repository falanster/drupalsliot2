define({
	"button.createulist.tooltip": "Inserir lista sem ordenação",
	"button.createolist.tooltip": "Inserir lista ordenada",
	"button.indentlist.tooltip": "Recuar lista",
	"button.outdentlist.tooltip": "Recuar lista",
	"floatingmenu.tab.list": "Listas"
});
