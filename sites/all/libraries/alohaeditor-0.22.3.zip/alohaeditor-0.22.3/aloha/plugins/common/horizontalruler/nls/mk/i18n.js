define({
	"button.addhr.tooltip": "Додади хоризонтален линијар"
});
