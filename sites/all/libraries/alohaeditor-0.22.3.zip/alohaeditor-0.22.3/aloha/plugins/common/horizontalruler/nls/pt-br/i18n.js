define({
	"button.addhr.tooltip": "Adicionar régua horizontal"
});
