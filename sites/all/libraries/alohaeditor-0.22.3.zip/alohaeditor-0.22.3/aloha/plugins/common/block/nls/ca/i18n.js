define({
	"button.toggledragdrop.tooltip": "Habilita/deshabilita la funcionalitat d\'arrossegar i deixar anar"
});
