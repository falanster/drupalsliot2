define({
	"button.alignright.tooltip": "Подреди надесно",
	"button.alignleft.tooltip": "Подреди налево",
	"button.aligncenter.tooltip": "Центрирај",
	"button.alignjustify.tooltip": "Подреди подеднакво"
});
