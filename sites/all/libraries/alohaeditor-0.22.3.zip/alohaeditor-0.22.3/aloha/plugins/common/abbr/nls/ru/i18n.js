define({
	"floatingmenu.tab.abbr": "Аббревиатура",
	"button.addabbr.tooltip": "вставить аббревиатуру",
	"button.abbr.tooltip": "форматировать как аббревиатуру",
	"newabbr.defaulttext": "Сокр."
});
