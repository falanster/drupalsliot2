define({
	"button.addimage.tooltip": "Insereix una imatge",
	"button.removeimage.tooltip": "Suprimeix la imatge",
	"newimage.defaulttext": "Imatge nova",
	"floatingmenu.tab.img": "Imatge"
});
