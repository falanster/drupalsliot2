define({
	"button.formatlessPaste.tooltip": "切换无格式粘贴"
});
