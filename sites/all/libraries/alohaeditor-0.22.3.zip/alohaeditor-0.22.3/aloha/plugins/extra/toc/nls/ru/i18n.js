define({
	"button.addtoc.tooltip": "Оглавление"
});
