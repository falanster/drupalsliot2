define({
	"button.addimage.tooltip": "插入图像",
	"button.removeimage.tooltip": "移除图像",
	"newimage.defaulttext": "新图像",
	"floatingmenu.tab.img": "图像"
});
