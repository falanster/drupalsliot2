define({
	"root":  {
		"headerids.label.target": "Target",
		"headerids.button.reset": "Reset",
		"headerids.button.set": "Set"
	},
		"ca": true,
		"de": true,
		"mk": true,
		"pt-br": true,
		"ru": true,
		"uk": true,
		"zh-hans": true
});
