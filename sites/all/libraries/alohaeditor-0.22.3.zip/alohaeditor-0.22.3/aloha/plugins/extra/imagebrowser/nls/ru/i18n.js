define({
	"button.addimage.tooltip": "Вставить изображение",
	"button.removeimage.tooltip": "Удалить изображение",
	"newimage.defaulttext": "Новое изображение",
	"floatingmenu.tab.img": "Изображение"
});
