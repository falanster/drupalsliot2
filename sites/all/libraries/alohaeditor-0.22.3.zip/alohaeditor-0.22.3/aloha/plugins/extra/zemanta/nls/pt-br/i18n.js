define({
	"floatingmenu.tab.related": "Relacionado",
	"button.zemanta.tooltip": "Zemanta",
	"zemanta.message.shorttext": "Para encontrar artigos, imagens ou tags relacionados o serviço Zemanta precisa mais de 140 caracteres."
});
