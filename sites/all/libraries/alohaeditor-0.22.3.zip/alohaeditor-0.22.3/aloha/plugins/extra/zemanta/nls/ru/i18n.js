define({
	"floatingmenu.tab.related": "Связанные",
	"button.zemanta.tooltip": "Zemanta",
	"zemanta.message.shorttext": "Для поиска связанных статей, изображений или тегов сервису Zemanta необходимо больше, чем 140 символов."
});
