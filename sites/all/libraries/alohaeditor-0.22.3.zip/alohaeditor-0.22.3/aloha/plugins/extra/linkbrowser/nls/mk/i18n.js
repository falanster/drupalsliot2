define({
	"button.addlink.tooltip": "Внеси линк",
	"button.removelink.tooltip": "Одстрани линк",
	"newlink.defaulttext": "Нов линк",
	"floatingmenu.tab.link": "Линк"
});
