define({
	"cite.button.add.quote": "Стилизирај го одбележаното како цитат",
	"cite.button.add.blockquote": "Стилизирај го одбележаното како блок од цитат"
});
