define({
	"button.addimage.tooltip": "Bild einfügen",
	"button.removeimage.tooltip": "Bild löschen",
	"newimage.defaulttext": "Neues Bild",
	"floatingmenu.tab.img": "Bild"
});
