define({
	"button.addimage.tooltip": "Inserir imagem",
	"button.removeimage.tooltip": "Remover imagem",
	"newimage.defaulttext": "Nova imagem",
	"floatingmenu.tab.img": "Imagem"
});
