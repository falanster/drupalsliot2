define({
	"cite.button.add.quote": "Форматировать выделение как цитату",
	"cite.button.add.blockquote": "Форматировать выделение как блок цитаты"
});
