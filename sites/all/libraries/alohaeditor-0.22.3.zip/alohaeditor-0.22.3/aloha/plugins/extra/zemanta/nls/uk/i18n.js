define({
	"floatingmenu.tab.related": "Пов\'язані",
	"button.zemanta.tooltip": "Zemanta",
	"zemanta.message.shorttext": "Щоб знайти пов\'язані статті, зображення чи теги сервісу Zemanta необхідно більше, ніж 140 символів."
});
