define({
	"headerids.label.target": "Objectiu",
	"headerids.button.reset": "Restableix",
	"headerids.button.set": "Estableix"
});
