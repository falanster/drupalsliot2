define({
	"cite.button.add.quote": "Formata la selecció com una cita",
	"cite.button.add.blockquote": "Formata la selecció com una cita llarga"
});
