define({
	"floatingmenu.tab.wai-lang": "Sprachauszeichnung",
	"button.add-wai-lang-remove.tooltip": "Sprachauszeichnung entfernen",
	"button.add-wai-lang.tooltip": "Sprachauszeichnung hinzufügen"
});
