define({
	"floatingmenu.tab.file": "Datei"
});
