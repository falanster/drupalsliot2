define({
	"cite.button.add.quote": "Форматувати виділене як цитату",
	"cite.button.add.blockquote": "Форматувати виділене як блок цитати"
});
